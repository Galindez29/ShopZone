---
title: "Página de ejemplo"
body: "Este es un texto editable desde Netlify CMS."
---
